//
//  AlamofireManager.swift
//  market
//
//  Created by 钟 文汉 on 2018/5/28.
//  Copyright © 2018年 钟 文汉. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
//import Bugsnag

class AlamofireManager: NSObject {

    var sessionManager : Alamofire.SessionManager?

    
    func sendRequest(_ type:NSInteger , api : String , param: [String: Any]? = nil , result : @escaping returnResponses)->String{
        let httpmethod:HTTPMethod
        if type == 0 {
            httpmethod = HTTPMethod.get
        }else{
            httpmethod = HTTPMethod.post
        }
        if sessionManager == nil{
            
            let configuration = URLSessionConfiguration.default
            configuration.timeoutIntervalForRequest = 10
            sessionManager = Alamofire.SessionManager(configuration: configuration)
        }
        let user = UserDefaults.standard
        
        var to = user.string(forKey: "token")
        if to == nil {
            to = ""
        }
        //TODO: token
        let token = to!
        
        let header : HTTPHeaders = ["token" : token]

        sessionManager?.request(api, method: httpmethod, parameters: param, encoding: URLEncoding.httpBody, headers: header).responseString(completionHandler: { Response in

            
            if Response.result.isSuccess==true
            {
                do {
                    
                    let data = try JSONSerialization.jsonObject(with: Response.data!, options: .mutableContainers)
                    let json = data as! [String:Any]
                    
                    self.handleRespone(json, result: result)
                    
                }catch{
                    
                    print(Response)
                    result("", false , 500 , "请求错误")
                }
                
            }
            else{
                
//                if Response.result.error != nil{
//
//                    Bugsnag.notifyError(Response.result.error!)
//                }else{
//
//                    Bugsnag.notifyError(NSError(domain:api, code:0, userInfo:param))
//                }
                print(Response)
                result("", false , 500 , "请求错误")
            }


        })
        
        return api
    }
    
    func handleRespone(_ json: [String: Any], result : @escaping returnResponses){
        
        let success = json["success"]as? Bool ?? false
        let msg = json["msg"]as? String ?? ""
        let code = json["code"]as? Int ?? 0
        
        if success == true
        {
            let data = json["data"]
            result(data, true , 200 , msg)
        }
        else{
            
            if msg == "token expired" || msg == "token erro"{
                
                result("", false , 500 , "验证过期，请重新登录")
            }
            else{
                
                result("", false , code , msg)
                
                
            }
            
        }

    }
    
    
    @available(iOS 9.0, *)
    func cancelRequest(_ urls : [String]){
        
        sessionManager?.session.getAllTasks(completionHandler: { (tasks) in
            
            tasks.forEach({ (task) in
                
                if urls.contains((task.currentRequest?.url?.lastPathComponent)!) {
                    
                    task.cancel()
                }
            })
        })
    }
}

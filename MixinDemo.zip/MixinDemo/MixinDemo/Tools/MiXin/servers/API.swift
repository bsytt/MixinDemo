//
//  API.swift
//  market
//
//  Created by 钟 文汉 on 2018/10/8.
//  Copyright © 2018年 钟 文汉. All rights reserved.
//

import UIKit

class API: NSObject {
    
    //TODO: your domain name
    static let userDomain : String = "https://xxx"//自己服务器d地址

    // 登录注册一起
    class func logins()->String{
        
        return userDomain + "api/v1/" + "login"
    }
    
    // 获取手机验证码
    class func messageCode()->String{
        
        return userDomain + "api/v1/" + "get_code"
    }
    
    // 修改用户信息
    class func updateUserInfo()->String{
        
        return userDomain + "api/v1/" + "update_user_info"
    }
    
    // 获取某个币种详情（可以直接调mixin接口）
    class func getAsset()->String{
        
        return userDomain + "api/v1/" + "asset"
    }
    
    //获取资产列表（可以直接调mixin接口）
    class func getAssets()->String{
        
        return userDomain + "api/v1/" + "assets"
    }
    
    // 获取转账列表
    class func getTransationRecords()->String{
        
        return userDomain + "api/v1/" + "get_records"
    }
    
    // 获取地址簿（可以直接调mixin接口）
    class func getWithdrawAddress()->String{
    
        return userDomain + "api/v1/" + "get_withdrawal_address"
    }
    
    // 创建地址簿（可以直接调mixin接口）
    class func creatWithdrawAddress()->String{
        
        return userDomain + "api/v1/" + "create_withdrawal_address"
    }
    
    // 删除地址簿（可以直接调mixin接口）
    class func deleteWithdrawAddress()->String{
        
        return userDomain + "api/v1/" + "delete_withdrawal_address"
    }
    
    //根据手机号获取用户id
    class func searchUser(phoneNum: String)->String{
        
        return userDomain + "api/v1/search?phone_num=" + phoneNum
    }

}

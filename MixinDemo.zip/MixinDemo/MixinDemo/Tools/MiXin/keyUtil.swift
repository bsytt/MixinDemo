//
//  keyUtil.swift
//  MaggieDating
//
//  Created by 包曙源 on 2018/10/23.
//  Copyright © 2018年 com.maggie.social.maggieDating. All rights reserved.
//

import UIKit
import Goutils
import CommonCrypto
class keyUtil: NSObject {
    
    static func stripRsaPrivateKeyHeaders(_ pemString: String) -> String {
        let lines = pemString.components(separatedBy: "\n").filter { line in
            return !line.hasPrefix("-----BEGIN") && !line.hasPrefix("-----END")
        }
        
        guard lines.count != 0 else {
            return pemString
        }
        
        return lines.joined(separator: "")
    }
    

    static func aesEncrypt(pinToken: String, pin: String, privateKey: String, sessionID: String) -> String? {
        
        let dectytoPinToken = rsaDecrypt(pkString: privateKey, sessionId: sessionID, pinToken: pinToken)
        
        guard let key = Data(base64Encoded: dectytoPinToken), let data = pin.data(using: .utf8), let iv = secureRandom() else {
            
            return nil
        }
        
        
        
        let now = Date()
        let timeInterval:TimeInterval = now.timeIntervalSince1970
        let timeStamp = UInt64(timeInterval * 1000 * 1000)
        
        var nowInterval = UInt64(Date().timeIntervalSince1970).littleEndian
        let timeData = Data(bytes: &nowInterval, count: MemoryLayout<UInt64>.size)
        var iterator = timeStamp.littleEndian
        let iteratorData = Data(bytes: &iterator, count: MemoryLayout<UInt64>.size)
//      CryptoUserDefault.shared.iterator = iterator + 1
        
        var dataOut = [UInt8](repeating: 0, count: kCCBlockSizeAES128 + timeData.count + iteratorData.count)
        var numBytesEncrypted = 0
        
        let cryptStatus = CCCrypt(CCOperation(kCCEncrypt), CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionPKCS7Padding), key.bytes, key.count, iv, data.bytes + timeData.bytes + iteratorData.bytes, data.count + timeData.count + iteratorData.count, &dataOut, dataOut.count, &numBytesEncrypted)
        
        guard cryptStatus == CCCryptorStatus(kCCSuccess) else {
            
            return nil
        }
        
        return Data(bytes: iv + dataOut.prefix(numBytesEncrypted)).base64EncodedString()
    }
    
    static func secureRandom(blockSize: Int = kCCBlockSizeAES128) -> [UInt8]? {
        var iv = [UInt8](repeating: 0, count: blockSize)
        if SecRandomCopyBytes(kSecRandomDefault, blockSize, &iv) != 0 {
            return nil
        }
        return iv
    }
    
    static func rsaDecrypt(pkString: String, sessionId: String, pinToken: String) -> String {
        var error: NSError?
        defer {
            if let err = error  {
                print("decode pintoken error")
            }
        }
        return GoutilsRsaDecrypt(pinToken, sessionId, pkString, &error)
    }
}

extension Data {
    
    func toHexString() -> String {
        return map { String(format: "%02.2hhx", $0) }.joined()
    }
    
    var bytes : [UInt8] {
        return [UInt8](self)
    }
    
    func toString() -> String
    {
        return String(data: self, encoding: .utf8)!
    }
}

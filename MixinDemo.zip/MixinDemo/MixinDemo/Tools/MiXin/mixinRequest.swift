//
//  mixinRequest.swift
//  MaggieDating
//
//  Created by 包曙源 on 2018/10/23.
//  Copyright © 2018年 com.maggie.social.maggieDating. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

public typealias returnResponses = (_ data : Any , _ success : Bool , _ code : NSInteger , _ msg : String)->Void

class mixinRequest: NSObject {
    
    let mixinURL = "https://api.mixin.one/"
    
    private func creatRequest(_ httpmethod: HTTPMethod , url: String , param: Parameters? = nil)->URLRequest{
        
        var originalRequest: URLRequest?
        
        do{
            
            originalRequest = URLRequest(url: URL.init(string: mixinURL + url)!)
            originalRequest?.httpMethod = httpmethod.rawValue
            var encodedURLRequest = try JSONEncoding().encode(originalRequest!, with: param)
            encodedURLRequest.allHTTPHeaderFields = tokenEncryption.getJwtHeaders(request: encodedURLRequest, uri: url)
            return encodedURLRequest
            
            
        }catch{
            
            print("mixin urlRequest creat error")
            return URLRequest(url: URL.init(string: mixinURL + url)!)
            
        }
        
    }

    func request(type:NSInteger, url: String , param: Parameters? = nil, result : @escaping returnResponses)-> String{
        var request = creatRequest(HTTPMethod .get, url: url, param: param)
        if type == 0 {
            request = creatRequest(HTTPMethod .get, url: url, param: param)
        }else {
            request = creatRequest(HTTPMethod .post, url: url, param: param)
        }
//        let request = creatRequest(HTTPMethod .get, url: url, param: param)
        Alamofire.request(request).responseJSON { (Response) in
            
            if Response.result.isSuccess==true
            {
                let json = JSON.init(Response.result.value!)
                print("[mixin] --> json:\(json)")
                self.handleRespone(json, result: result)
                
            }else{
                
                print("[mixin] --> Response:\(Response)")
                result("", false , 500 , "请求错误，请重试")
            }
        }
        
        return (mixinURL + url)
    }
    
    private func handleRespone(_ json: JSON, result : @escaping returnResponses){
        
        if json["error"].dictionary != nil{
            
            let error = json["error"].dictionaryValue
            let code = error["code"]?.intValue
            let msg = error["description"]?.stringValue
            result("", false , code! , msg!)
            
        }else{
            
            if let data = json["data"].arrayObject{
                
                result(data, true , 200 , "")
                
            }else if let data = json["data"].dictionaryObject{
                
                result(data, true , 200 , "")
                
            }else{
                
                result("", true , 200 , "")
            }
            
        }
    }
    
}

//
//  mixinAPI.swift
//  MaggieDating
//
//  Created by 包曙源 on 2018/10/23.
//  Copyright © 2018年 com.maggie.social.maggieDating. All rights reserved.
//
import UIKit

class mixinAPI: NSObject {
    
    /// Creat of update pin. If you do not set pin ever, then default pin is "".
    //    param{
    //
    //        "old_pin":"String: “” OR Old Encrypted PIN.",
    //        "pin":"String: Encrypted New PIN."
    //    }
    class func creat_pin()->String{
        
        return "pin/update"
    }
    
    /// Useing pin to get user infomations.
    //    param{
    //
    //        "pin":"String: Encrypted PIN."
    //    }
    class func verify_pin()->String{
        
        return "pin/verify"
    }
    
    /// Useing user_id transfer coin to others without fee.
    //    param{
    //
    //        "asset_id":"String: asset_id",
    //        "opponent_id":"String: user_id",
    //        "amount":"String: e.g.: “0.01”",
    //        "pin":"String: Encrypted Pin",
    //        "trace_id":"String: UUID",
    //        "memo":"String: Max 140 characters, e.g.: “transfer to you”"
    //    }
    class func transfer()->String{
        
        return "transfers"
    }
    
    /// Withdraw coin outside the mixin network.
    //    param{
    //        "address_id":"String: address_id",
    //        "amount":"String: e.g.: “0.01”",
    //        "pin":"String: Encrypted Pin",
    //        "trace_id":"String: UUID",
    //        "memo":"String: Max 140 characters, e.g.: “transfer to you”"
    //    }
    class func withdrawals()->String{
        
        return "withdrawals"
    }
    
    /// Before withdraw coin, should get a addressID.
    class func getWithdrawAddressesID(asset_id: String)->String{
        
        return "assets/\(asset_id)/addresses"
    }
    
    /// Creat a withdraw addressID.
    //    param{
    //        "asset_id":"String: asset_id",
    //        "amount":"String: e.g.: “0.01”",
    //        "pin":"String: Encrypted Pin",
    //        "trace_id":"String: UUID",
    //        "memo":"String: Max 140 characters, e.g.: “transfer to you”"
    //    }
    class func creatAddressId()->String{
        
        return "addresses"
    }
    
    /// Read asset detail infomations.
    //    param{
    //        "asset_id":"String: UUID",
    //        "public_key":"String: asset address (optional)",
    //        "label":"String: “OceanONE”",
    //        "account_name":"String: EOS account name (optional)",
    //        "account_tag":"String: EOS account tag (optional)",
    //        "pin":"String: Encrypted PIN"
    //    }
    class func getAsset(asset_id: String)->String{
        
        return "assets/\(asset_id)"
    }
    
    class func deleteAddress(address_id: String)->String{
        return "addresses/\(address_id)/delete"
    }
    class func readAssets()->String{
        return "assets"
    }
    /// Read user profile.
    class func readSelfProfile()->String{
        return "me"
    }
    
}


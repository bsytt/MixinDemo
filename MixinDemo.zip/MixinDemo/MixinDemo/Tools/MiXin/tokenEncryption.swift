//
//  tokenEncryption.swift
//  MaggieDating
//
//  Created by 包曙源 on 2018/10/23.
//  Copyright © 2018年 com.maggie.social.maggieDating. All rights reserved.
//
import UIKit
import JWT
import Alamofire
import CommonCrypto
class tokenEncryption: NSObject {
    
    private static let baseHeaders: HTTPHeaders = [
        "Content-Type": "application/json"
    ]
    private static let headersAuthroizationKey = "Authorization"
    
    private static func signToken(sessionId: String, userId: String, authenticationToken: String, request: URLRequest, uri: String) -> String? {
        var sig = ""
        if let method = request.httpMethod {
            sig += method
        }
        if !uri.hasPrefix("/") {
            sig += "/"
        }
        sig += uri
        if let body = request.httpBody, let content = String(data: body, encoding: .utf8), content.count > 0 {
            sig += content
        }
        var claims: [AnyHashable: Any] = [:]
        claims["uid"] = userId
        claims["sid"] = sessionId
        claims["iat"] = UInt64(Date().timeIntervalSince1970)
        claims["exp"] = UInt64(Date().addingTimeInterval(60 * 30).timeIntervalSince1970)
        claims["jti"] = UUID().uuidString.lowercased()
        claims["sig"] = sig.sha256()
        claims["scp"] = "FULL"
        
        let token = keyUtil.stripRsaPrivateKeyHeaders(authenticationToken)
        let keyType = JWTCryptoKeyExtractor.privateKeyWithPEMBase64()
        var holder: JWTAlgorithmRSFamilyDataHolder? = JWTAlgorithmRSFamilyDataHolder()
        holder = holder?.keyExtractorType(keyType?.type)
        holder = holder?.algorithmName("RS512") as? JWTAlgorithmRSFamilyDataHolder
        holder = holder?.secret(token) as? JWTAlgorithmRSFamilyDataHolder
        var builder = JWTEncodingBuilder.encodePayload(claims)
        builder = builder?.addHolder(holder) as? JWTEncodingBuilder
        let result = builder?.result?.successResult?.encoded
        
        return result
    }
    
    static func getJwtHeaders(request: URLRequest, uri: String) -> HTTPHeaders {
        
        let userDefaults = UserDefaults.standard
   
        var session_id = userDefaults.string(forKey: "session_id")
        var user_id = userDefaults.string(forKey: "user_id")
        var private_key = userDefaults.string(forKey: "private_key")
        if session_id == nil {
            session_id = ""
        }
        if user_id == nil {
            user_id = ""
        }
        if private_key == nil {
            private_key = ""
        }
        //TODO: param setting
        let sessionID = session_id!
        let userID = user_id!
        let token = private_key! // privateKey
        
        var headers = baseHeaders
        
        if token != ""{
            if let signedToken = signToken(sessionId: sessionID, userId: userID, authenticationToken: token, request: request, uri: uri) {
                headers[headersAuthroizationKey] = "Bearer " + signedToken

            } else {
                print("mixin signToken is nil")
            }
        }
        return headers
    }
    
}

extension String{
    
    func sha256() -> String{
        if let stringData = self.data(using: String.Encoding.utf8) {
            return hexStringFromData(input: digest(input: stringData as NSData))
        }
        return ""
    }
    
    private func digest(input : NSData) -> NSData {
        let digestLength = Int(CC_SHA256_DIGEST_LENGTH)
        var hash = [UInt8](repeating: 0, count: digestLength)
        CC_SHA256(input.bytes, UInt32(input.length), &hash)
        return NSData(bytes: hash, length: digestLength)
    }
    
    private  func hexStringFromData(input: NSData) -> String {
        var bytes = [UInt8](repeating: 0, count: input.length)
        input.getBytes(&bytes, length: input.length)
        
        var hexString = ""
        for byte in bytes {
            hexString += String(format:"%02x", UInt8(byte))
        }
        
        return hexString
    }
}

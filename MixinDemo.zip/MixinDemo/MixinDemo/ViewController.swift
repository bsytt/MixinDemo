//
//  ViewController.swift
//  MixinDemo
//
//  Created by 包曙源 on 2018/11/20.
//  Copyright © 2018年 包曙源. All rights reserved.
//

import UIKit


//首先
/*
 通常情况下后台去Mixin申请，然后回提供一个注册登录接口(注册和登录都走这个借口)，会得到数据如下:
 ClientId        = "89e0bdee-c355-47f2-945a-be48be875606"
 ClientSecret    = "2d9c60d4b4dd2185d2938229ac76fea2b69440fbff4608cbbf80b32a5a598368"
 SessionId       = "c09cf313-7ded-425d-ad3f-a1ce4cfd5e5e"
 PinToken        = "GSusC2myf/meJJnqorrcg2EWnHEAFXoT4so36ggrM4WSRGXFGtPDo3CZCQhldMpFc84MdvdS94tZ4na+0NUWIkkXOMSLFfubf6PNS2DrlC+xjQWjWYN1Py8Y0SDyP1AjQe5+7iXrCoiyrBOxatov5UbRFrTJDX9Jgqh9fTFJfR4="
 PrivateKey      = `-----BEGIN RSA PRIVATE KEY-----
 MIICXAIBAAKBgQCKUnJ8IEiGci7Gu+oKoy6I1wy0H3f2BwHBcSSVy5sglDHHTlBA
 Czg6HcNuy5PXfdrulpz0tr4Prn5x5upUH6CrL8dAT6oUB3V72f0gqSWde90APlsH
 ZVSYFaq6PxqZ2HJg40aXAvHiuGbqwmN5LZiDdR0uewTDZjUo1rijqPb2fwIDAQAB
 AoGACReqVuZ4Xf4bfQzVMaXQZUZdm2mGJTIIt4KMeRxNMjMLoqJPPCaAp7FVK29O
 ZJftUEmuP5fTnoxF247mUGlT0lQtIv3E5sSFTpzwYu8No9+Whpr4/rYgJ4OBpAE/
 i3lTPwKXnHvkTDcrlCc8rGdN4oVmnFVwOM5tUBZtBKKLh2ECQQDCSYiWJ0nQul9e
 pVn4yv0s3ur/VHoLqNvqV38vpieiV9cVwSpuXN3evSDb9k0CC/Qmn7PXfKN7zLhX
 z/t2rzDbAkEAtkIa6NGsasg8b/4r+zHOWU8B51bLNC6b3NEAakgxB9Qo82Wgqmdf
 64C1DZjuIee6InLq1DoGzM68z+XcRzAgLQJAGKTtL2ayZUiOulmtDPLqpFtuYY7c
 oEf+BT6uAmRIGL6dqMPE1xTui8dfuKcIY58SjCerz0SfFCAGrhTSp95XCwJAQR1A
 6+jtBoFfRkuyft3+cN3POk1B7/Su7qck1NPR4JAlyT+HtRmVpVeoV6FJgod9co1H
 5GaOw2EhB82Bc1V4SQJBAIi8gIyTW4ITfuhyXPepIOlVKe2DfGMB0bNLHj/VSrV6
 tUUyTyrnVfJsARw5YUjkvzm81Sd8mvQBr5HR+IKXYco=
 -----END RSA PRIVATE KEY-----`
 user_id         = "89e0bdee-c355-47f2-945a-be48be875606"
 
 
 
 主要需要 pin_token，private_key，session_id，token，user_id" 需要保存本地
 pin_token，private_key，session_id用于加密pin码（相当于取款码）
 token传到自己后台服务器请求Mixin的header里
 */
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let pinToken = "GSusC2myf/meJJnqorrcg2EWnHEAFXoT4so36ggrM4WSRGXFGtPDo3CZCQhldMpFc84MdvdS94tZ4na+0NUWIkkXOMSLFfubf6PNS2DrlC+xjQWjWYN1Py8Y0SDyP1AjQe5+7iXrCoiyrBOxatov5UbRFrTJDX9Jgqh9fTFJfR4="
        let privateKey = "`-----BEGIN RSA PRIVATE KEY-----MIICXAIBAAKBgQCKUnJ8IEiGci7Gu+oKoy6I1wy0H3f2BwHBcSSVy5sglDHHTlBACzg6HcNuy5PXfdrulpz0tr4Prn5x5upUH6CrL8dAT6oUB3V72f0gqSWde90APlsHZVSYFaq6PxqZ2HJg40aXAvHiuGbqwmN5LZiDdR0uewTDZjUo1rijqPb2fwIDAQABAoGACReqVuZ4Xf4bfQzVMaXQZUZdm2mGJTIIt4KMeRxNMjMLoqJPPCaAp7FVK29OZJftUEmuP5fTnoxF247mUGlT0lQtIv3E5sSFTpzwYu8No9+Whpr4/rYgJ4OBpAE/i3lTPwKXnHvkTDcrlCc8rGdN4oVmnFVwOM5tUBZtBKKLh2ECQQDCSYiWJ0nQul9epVn4yv0s3ur/VHoLqNvqV38vpieiV9cVwSpuXN3evSDb9k0CC/Qmn7PXfKN7zLhXz/t2rzDbAkEAtkIa6NGsasg8b/4r+zHOWU8B51bLNC6b3NEAakgxB9Qo82Wgqmdf64C1DZjuIee6InLq1DoGzM68z+XcRzAgLQJAGKTtL2ayZUiOulmtDPLqpFtuYY7coEf+BT6uAmRIGL6dqMPE1xTui8dfuKcIY58SjCerz0SfFCAGrhTSp95XCwJAQR1A6+jtBoFfRkuyft3+cN3POk1B7/Su7qck1NPR4JAlyT+HtRmVpVeoV6FJgod9co1H5GaOw2EhB82Bc1V4SQJBAIi8gIyTW4ITfuhyXPepIOlVKe2DfGMB0bNLHj/VSrV6tUUyTyrnVfJsARw5YUjkvzm81Sd8mvQBr5HR+IKXYco=-----END RSA PRIVATE KEY-----`"
        let sessionId = "c09cf313-7ded-425d-ad3f-a1ce4cfd5e5e"
        //注册登录之后
        //一
        //通过这个接口返回的has_pin来判断用户是否设置过pin码
        let api = mixinAPI.readSelfProfile()
        let req = mixinRequest()
        let urlStr = req.request(type: 0, url: api, param: nil) { (data, suc, code, msg) in
            
        }
        print(urlStr)
        
        //二
        //取出注册登录接口返回的pinToken，privateKey，sessionId
        let creat_pin = mixinAPI.creat_pin()
        let pin = keyUtil .aesEncrypt(pinToken:pinToken, pin: "123456", privateKey:privateKey, sessionID: sessionId)
        let urlStr1 = req.request(type: 1, url: creat_pin, param: ["old_pin":"","pin":pin!]) { (data, suc, code, msg) in
            
        }
        print(urlStr1)

        //三
        //获取资产列表，注：由于用户刚注册时没有资产，所以Minxin返回的为空，需要后台z一个接口专门写一些资产，点击单个资产后再请求Mixin获取单个资产的方法
        //（如果要在资产列表展示行情，一般后台回写死一个近期的行情，否则会出现d进入列表也没有，点击单个资产返回后刷新出行情的bug）
        let readAssets = mixinAPI.readAssets()
        let urlStr2 = req.request(type: 0, url: readAssets, param: nil) { (data, suc, code, msg) in
            //这里的用户资产总额，总额兑换btc多少需要自己计算（法币兑换只返回美元的兑换率，没有人民币）
        }
        print(urlStr2)
        
        //四
        //获取指定资产详情，根据asset_id获取
//        NSString *url = [mixinAPI getAssetWithAsset_id:_model.asset_id];
        let url = mixinAPI.getAsset(asset_id: "")
        let urlStr3 = req.request(type: 0, url: url, param: nil) { (data, suc, code, msg) in
            //这里的用户资产总额，总额兑换btc多少需要自己计算（法币兑换只返回美元的兑换率，没有人民币）
        }
        print(urlStr3)
        //转账记录后台配置即可
        
        //五
        //获取地址簿（如果要实现手机号内部转账的地址簿需要后台添加接口，使用后台接口即可）
//        NSString *url = [mixinAPI getWithdrawAddressesIDWithAsset_id:_model.asset_id];
        let addresses = mixinAPI.getWithdrawAddressesID(asset_id: "")
        let urlStr4 = req.request(type: 0, url: addresses, param: nil) { (data, suc, code, msg) in
        }
        print(urlStr4)
        
        //六
        //添加地址簿
        //这个接口需要输入pin码。同二的获取方式
        //EOS和BTS和其它币不一样
        let creatAddressId = mixinAPI.creatAddressId()
        let dic = ["asset_id":"","public_key":"EOS和BTS不使用这个","label":"","account_name":"EOS和BTS这个不能为空","account_tag":"EOS和BTS这个不能为空","pin":pin]
//
        let urlStr5 = req.request(type: 1, url: creatAddressId, param: dic) { (data, suc, code, msg) in
        }
        print(urlStr5)
        
        //七
        //转账
        //EOS和BTS和其它币不一样
        let uuid = UUID().uuidString.lowercased()
        let withdrawals = mixinAPI.withdrawals()
        let dict = ["address_id":"","amount":"0.1","pin":pin,"trace_id":uuid
            ,"memo":""]
        //
        let urlStr6 = req.request(type: 1, url: withdrawals, param: dict) { (data, suc, code, msg) in
            
        }
        print(urlStr6)
        
        //八
        //内部转账（请求后台接口通过手机号获得用户Minxin的UserId，通过UserId转账）
        let transfer = mixinAPI.transfer()
        let dicc = ["asset_id":"","amount":"0.1","opponent_id":"userId","pin":pin,"trace_id":uuid
            ,"memo":""]
        let urlStr7 = req.request(type: 1, url: transfer, param: dicc) { (data, suc, code, msg) in
            
        }
        print(urlStr7)
           
    }


}

